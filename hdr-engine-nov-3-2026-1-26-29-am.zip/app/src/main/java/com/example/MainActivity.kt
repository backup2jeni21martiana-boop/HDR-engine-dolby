package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.HdrEngineScreen
import com.example.ui.HdrEngineViewModel
import com.example.ui.theme.HdrEngineTheme

class MainActivity : ComponentActivity() {

    private val viewModel: HdrEngineViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HdrEngineTheme {
                HdrEngineScreen(viewModel = viewModel)
            }
        }
    }
}
