package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.MasteringState
import com.example.model.OutputProfile
import com.example.processor.HdrEngineProcessor
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

sealed class UiEvent {
    data class ShowToast(val message: String, val isError: Boolean = false) : UiEvent()
}

class HdrEngineViewModel(application: Application) : AndroidViewModel(application) {

    private val processor = HdrEngineProcessor(application.applicationContext)

    private val _uiState = MutableStateFlow(MasteringState())
    val uiState: StateFlow<MasteringState> = _uiState.asStateFlow()

    private val _eventFlow = MutableSharedFlow<UiEvent>()
    val eventFlow: SharedFlow<UiEvent> = _eventFlow.asSharedFlow()

    fun onVideoPicked(uri: Uri) {
        if (_uiState.value.isProcessing) return
        try {
            val videoInfo = processor.parseVideoInfo(uri)
            _uiState.update { state ->
                state.copy(
                    sourceVideo = videoInfo,
                    statusMessage = "SOURCE LOADED READY FOR MASTERING",
                    lastLog = "Loaded source file: ${videoInfo.fileName} (${videoInfo.resolution})",
                    logHistory = listOf(
                        "> Initialized HDR Engine core",
                        "> Source file loaded: ${videoInfo.fileName}",
                        "> Resolution: ${videoInfo.resolution} | Codec: ${videoInfo.sourceCodec}"
                    ),
                    outputFilePath = null,
                    outputFileName = null,
                    progress = 0f
                )
            }
        } catch (e: Exception) {
            emitEvent("Gagal memproses file video: ${e.localizedMessage}", isError = true)
        }
    }

    fun onLoadSampleDemoVideo() {
        if (_uiState.value.isProcessing) return
        try {
            val sampleInfo = processor.createSampleDemoVideo()
            _uiState.update { state ->
                state.copy(
                    sourceVideo = sampleInfo,
                    statusMessage = "SAMPLE DEMO VIDEO LOADED",
                    lastLog = "Loaded demo SDR stream: ${sampleInfo.fileName}",
                    logHistory = listOf(
                        "> Loaded studio demo sample (1080p SDR 24fps)",
                        "> Color primaries: Rec.709 | Transfer: sRGB",
                        "> Ready for HEVC Main10 PQ ST2084 mastering"
                    ),
                    outputFilePath = null,
                    outputFileName = null,
                    progress = 0f
                )
            }
            emitEvent("Contoh video demo berhasil dimuat!", isError = false)
        } catch (e: Exception) {
            emitEvent("Gagal memuat demo: ${e.localizedMessage}", isError = true)
        }
    }

    fun onProfileSelected(profile: OutputProfile) {
        if (_uiState.value.isProcessing) return
        _uiState.update { it.copy(selectedProfile = profile) }
    }

    fun onFpsSelected(fps: String) {
        if (_uiState.value.isProcessing) return
        _uiState.update { it.copy(selectedFps = fps) }
    }

    fun onNitsChanged(nits: Int) {
        if (_uiState.value.isProcessing) return
        _uiState.update { it.copy(selectedNits = nits) }
    }

    fun onToggleAdvanced() {
        _uiState.update { it.copy(isAdvancedOpen = !it.isAdvancedOpen) }
    }

    fun onConvertToHdr() {
        val currentState = _uiState.value
        val source = currentState.sourceVideo
        if (source == null) {
            emitEvent("Pilih video sumber terlebih dahulu!", isError = true)
            return
        }

        val profile = currentState.selectedProfile
        val fps = currentState.selectedFps
        val nits = currentState.selectedNits

        _uiState.update { state ->
            state.copy(
                isProcessing = true,
                progress = 0.05f,
                statusMessage = "MASTERING VIDEO STREAM TO 10-BIT BT.2020...",
                lastLog = "Initializing FFmpeg Core...",
                logHistory = state.logHistory + listOf(
                    "--------------------------------------------------",
                    "> EXECUTE: MASTERING SDR -> ${profile.title}",
                    "> Target: BT.2020 WCG + SMPTE ST 2084 (PQ)",
                    "> Bit depth: 10-bit (yuv420p10le)",
                    "> Frame Engine: $fps | Peak: $nits NITs"
                )
            )
        }

        viewModelScope.launch {
            processor.executeMastering(source, profile, fps, nits).collect { step ->
                when (step) {
                    is HdrEngineProcessor.ProcessingStep.Progress -> {
                        _uiState.update { state ->
                            state.copy(
                                progress = step.progress,
                                statusMessage = step.status,
                                lastLog = step.log,
                                logHistory = (state.logHistory + step.log).takeLast(40)
                            )
                        }
                    }
                    is HdrEngineProcessor.ProcessingStep.Success -> {
                        _uiState.update { state ->
                            state.copy(
                                isProcessing = false,
                                progress = 1.0f,
                                statusMessage = "SUCCESS: MASTERING COMPLETED",
                                lastLog = "Output saved: ${step.outputFile.name}",
                                logHistory = state.logHistory + listOf(
                                    "> Output generated successfully",
                                    "> File: ${step.outputFile.absolutePath}",
                                    "> Size: ${step.outputFile.length() / 1024} KB",
                                    "> STATUS: READY TO PLAY / EXPORT"
                                ),
                                outputFilePath = step.outputFile.absolutePath,
                                outputFileName = step.outputFile.name,
                                generatedCommand = step.command
                            )
                        }
                        emitEvent("Konversi Berhasil! Disimpan ke: ${step.outputFile.name}", isError = false)
                    }
                    is HdrEngineProcessor.ProcessingStep.Error -> {
                        _uiState.update { state ->
                            state.copy(
                                isProcessing = false,
                                progress = 0f,
                                statusMessage = "ERROR: PROCESS TERMINATED",
                                lastLog = step.message,
                                logHistory = state.logHistory + "> ERROR: ${step.message}"
                            )
                        }
                        emitEvent(step.message, isError = true)
                    }
                }
            }
        }
    }

    fun onOpenOutputVideo() {
        val path = _uiState.value.outputFilePath ?: return
        val file = File(path)
        if (file.exists()) {
            processor.openVideoWithPlayer(file)
        } else {
            emitEvent("File video tidak ditemukan.", isError = true)
        }
    }

    fun onShareOutputVideo() {
        val path = _uiState.value.outputFilePath ?: return
        val file = File(path)
        if (file.exists()) {
            processor.shareVideo(file)
        } else {
            emitEvent("File video tidak ditemukan.", isError = true)
        }
    }

    private fun emitEvent(message: String, isError: Boolean = false) {
        viewModelScope.launch {
            _eventFlow.emit(UiEvent.ShowToast(message, isError))
        }
    }
}
