package com.example.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.OutputProfile
import com.example.model.SourceVideoInfo
import com.example.ui.theme.AmberDim
import com.example.ui.theme.AmberLight
import com.example.ui.theme.AmberPrimary
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkBorderHighlight
import com.example.ui.theme.DarkElevated
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.PureBlack
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.flow.collectLatest

@Composable
fun HdrEngineScreen(
    viewModel: HdrEngineViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.onVideoPicked(uri)
        }
    }

    LaunchedEffect(Unit) {
        viewModel.eventFlow.collectLatest { event ->
            when (event) {
                is UiEvent.ShowToast -> {
                    snackbarHostState.showSnackbar(
                        message = event.message,
                        withDismissAction = true
                    )
                }
            }
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("hdr_engine_screen"),
        containerColor = PureBlack,
        contentColor = TextPrimary,
        contentWindowInsets = WindowInsets.navigationBars,
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState) { data ->
                Snackbar(
                    containerColor = if (data.visuals.message.contains("Gagal", ignoreCase = true) ||
                        data.visuals.message.contains("Error", ignoreCase = true)
                    ) StatusError else AmberPrimary,
                    contentColor = if (data.visuals.message.contains("Gagal", ignoreCase = true) ||
                        data.visuals.message.contains("Error", ignoreCase = true)
                    ) Color.White else PureBlack,
                    shape = RoundedCornerShape(4.dp),
                    snackbarData = data
                )
            }
        },
        topBar = {
            HdrEngineTopBar()
        },
        bottomBar = {
            HdrEngineBottomBar(
                isProcessing = uiState.isProcessing,
                hasSource = uiState.sourceVideo != null,
                onConvertClicked = { viewModel.onConvertToHdr() }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            // 1. Header Card
            HeaderCard()

            Spacer(modifier = Modifier.height(18.dp))

            // 2. Source Video Section
            SourceVideoSection(
                sourceVideo = uiState.sourceVideo,
                isProcessing = uiState.isProcessing,
                onPickVideoClicked = {
                    videoPickerLauncher.launch(arrayOf("video/mp4", "video/x-matroska", "video/*"))
                },
                onLoadSampleClicked = { viewModel.onLoadSampleDemoVideo() }
            )

            Spacer(modifier = Modifier.height(18.dp))

            // 3. Frame Rate Engine Section
            FrameRateSection(
                selectedFps = uiState.selectedFps,
                isProcessing = uiState.isProcessing,
                onFpsSelected = { viewModel.onFpsSelected(it) }
            )

            Spacer(modifier = Modifier.height(18.dp))

            // 4. HDR Expansion (NITs) Section
            HdrExpansionSection(
                selectedNits = uiState.selectedNits,
                isProcessing = uiState.isProcessing,
                onNitsChanged = { viewModel.onNitsChanged(it) }
            )

            Spacer(modifier = Modifier.height(18.dp))

            // 5. Profile Output Section
            ProfileOutputSection(
                selectedProfile = uiState.selectedProfile,
                isProcessing = uiState.isProcessing,
                isAdvancedOpen = uiState.isAdvancedOpen,
                onProfileSelected = { viewModel.onProfileSelected(it) },
                onToggleAdvanced = { viewModel.onToggleAdvanced() }
            )

            Spacer(modifier = Modifier.height(18.dp))

            // 4. Processing Status Section
            ProcessingStatusSection(
                isProcessing = uiState.isProcessing,
                statusMessage = uiState.statusMessage,
                progress = uiState.progress,
                lastLog = uiState.lastLog,
                logHistory = uiState.logHistory,
                outputFilePath = uiState.outputFilePath,
                onPlayClicked = { viewModel.onOpenOutputVideo() },
                onShareClicked = { viewModel.onShareOutputVideo() }
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun HdrEngineTopBar() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(PureBlack)
            .padding(top = 16.dp, bottom = 12.dp, start = 16.dp, end = 16.dp)
            .testTag("hdr_top_bar")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Videocam,
                contentDescription = "Mastering Logo",
                tint = AmberPrimary,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "HDR ENGINE",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                color = AmberPrimary,
                letterSpacing = 2.0.sp
            )
        }
    }
}

@Composable
private fun HeaderCard() {
    ContainerBox(
        borderColor = AmberPrimary,
        borderWidth = 1.2.dp,
        modifier = Modifier.testTag("header_card")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(AmberDim)
                        .border(1.dp, AmberPrimary, RoundedCornerShape(4.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "H",
                        color = AmberPrimary,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 18.sp
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "H HDR MASTERING ENGINE",
                    color = AmberPrimary,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 15.sp,
                    letterSpacing = 1.2.sp
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = AmberPrimary, thickness = 1.dp)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "SDR → Dolby Vision Profile 8.4 menggunakan HEVC Main10, BT.2020, MCI 120FPS, dan PQ/ST2084 untuk kompatibilitas penuh TikTok HDR.",
                color = Color.LightGray,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                lineHeight = 17.sp
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                MasteringTag("10-BIT")
                MasteringTag("BT.2020")
                MasteringTag("DOLBY VISION")
                MasteringTag("120 FPS")
            }
        }
    }
}

@Composable
private fun MasteringTag(label: String) {
    Box(
        modifier = Modifier
            .background(DarkElevated, RoundedCornerShape(2.dp))
            .border(1.dp, Color(0xFF2C2C2C), RoundedCornerShape(2.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            color = AmberLight,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun SourceVideoSection(
    sourceVideo: SourceVideoInfo?,
    isProcessing: Boolean,
    onPickVideoClicked: () -> Unit,
    onLoadSampleClicked: () -> Unit
) {
    SectionContainer(title = "▪ SOURCE VIDEO", tag = "source_video_section") {
        Column(modifier = Modifier.fillMaxWidth()) {
            Button(
                onClick = onPickVideoClicked,
                enabled = !isProcessing,
                colors = ButtonDefaults.buttonColors(
                    containerColor = AmberPrimary,
                    contentColor = PureBlack,
                    disabledContainerColor = AmberDim,
                    disabledContentColor = Color.DarkGray
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("pilih_video_button")
            ) {
                Icon(
                    imageVector = Icons.Default.FolderOpen,
                    contentDescription = "Pilih Video",
                    tint = PureBlack,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "PILIH VIDEO",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    letterSpacing = 1.2.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // File path indicator box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF050505))
                    .border(1.dp, Color(0xFF222222))
                    .padding(10.dp)
                    .testTag("file_path_display")
            ) {
                Text(
                    text = sourceVideo?.filePath ?: "NO FILE SELECTED (Awaiting .mp4 / .mkv)",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = if (sourceVideo != null) AmberPrimary else TextMuted,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Technical metadata badges
            if (sourceVideo != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkElevated)
                        .border(1.dp, Color(0xFF1E1E1E))
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    MetadataRow("FILE NAME", sourceVideo.fileName)
                    MetadataRow("RESOLUTION", sourceVideo.resolution)
                    MetadataRow("INPUT COLOR", sourceVideo.sourceColorSpace)
                    MetadataRow("FRAME RATE", sourceVideo.frameRate)
                    MetadataRow("FILE SIZE", sourceVideo.fileSizeFormatted)
                }
            }
        }
    }
}

@Composable
private fun MetadataRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            color = TextMuted
        )
        Text(
            text = value,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = AmberLight
        )
    }
}

@Composable
private fun FrameRateSection(
    selectedFps: String,
    isProcessing: Boolean,
    onFpsSelected: (String) -> Unit
) {
    val options = listOf("Original", "60 FPS", "120 FPS")
    SectionContainer(title = "▪ FRAME RATE ENGINE", tag = "frame_rate_section") {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            options.forEach { fps ->
                val isSelected = selectedFps == fps
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isSelected) AmberPrimary.copy(alpha = 0.12f) else PureBlack)
                        .border(
                            width = if (isSelected) 1.5.dp else 1.dp,
                            color = if (isSelected) AmberPrimary else Color(0xFF2C2C2C),
                            shape = RoundedCornerShape(4.dp)
                        )
                        .clickable(enabled = !isProcessing) { onFpsSelected(fps) }
                        .padding(vertical = 10.dp, horizontal = 4.dp)
                        .testTag("fps_option_$fps"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(
                                        if (isSelected) AmberPrimary else Color.Transparent,
                                        CircleShape
                                    )
                                    .border(
                                        1.dp,
                                        if (isSelected) AmberPrimary else Color.Gray,
                                        CircleShape
                                    )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = fps,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = if (isSelected) AmberPrimary else TextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (fps == "Original") "Pass-through" else "Interpolate",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = if (isSelected) AmberLight else TextMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HdrExpansionSection(
    selectedNits: Int,
    isProcessing: Boolean,
    onNitsChanged: (Int) -> Unit
) {
    SectionContainer(title = "▪ HDR EXPANSION (NITs)", tag = "hdr_expansion_section") {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "PEAK BRIGHTNESS",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TextSecondary
                )
                Box(
                    modifier = Modifier
                        .background(PureBlack, RoundedCornerShape(4.dp))
                        .border(1.dp, AmberPrimary.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                        .testTag("nits_display")
                ) {
                    Text(
                        text = "$selectedNits NITs",
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black,
                        color = AmberPrimary,
                        letterSpacing = 1.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Slider(
                value = selectedNits.toFloat(),
                onValueChange = { onNitsChanged(it.toInt()) },
                valueRange = 400f..2000f,
                steps = 31,
                enabled = !isProcessing,
                colors = SliderDefaults.colors(
                    thumbColor = AmberPrimary,
                    activeTrackColor = AmberPrimary,
                    inactiveTrackColor = Color(0xFF333333)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("nits_slider")
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "400 NITs (Entry)",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextMuted
                )
                Text(
                    text = "1000 NITs (Master)",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextMuted
                )
                Text(
                    text = "2000 NITs (Cinema)",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextMuted
                )
            }
        }
    }
}

@Composable
private fun ProfileOutputSection(
    selectedProfile: OutputProfile,
    isProcessing: Boolean,
    isAdvancedOpen: Boolean,
    onProfileSelected: (OutputProfile) -> Unit,
    onToggleAdvanced: () -> Unit
) {
    SectionContainer(title = "▪ OUTPUT PROFILE", tag = "output_profile_section") {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ProfileRadioCard(
                    profile = OutputProfile.HDR10,
                    selected = selectedProfile == OutputProfile.HDR10,
                    isProcessing = isProcessing,
                    modifier = Modifier.weight(1f),
                    onSelected = { onProfileSelected(OutputProfile.HDR10) }
                )

                ProfileRadioCard(
                    profile = OutputProfile.HDR10_PLUS_MAX,
                    selected = selectedProfile == OutputProfile.HDR10_PLUS_MAX,
                    isProcessing = isProcessing,
                    modifier = Modifier.weight(1f),
                    onSelected = { onProfileSelected(OutputProfile.HDR10_PLUS_MAX) }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Advanced video parameters expandable toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleAdvanced() }
                    .padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Advanced",
                        tint = AmberLight,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "ADVANCED MASTERING PARAMS",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = AmberLight
                    )
                }
                Icon(
                    imageVector = if (isAdvancedOpen) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = "Toggle",
                    tint = TextMuted,
                    modifier = Modifier.size(18.dp)
                )
            }

            AnimatedVisibility(visible = isAdvancedOpen) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF050505))
                        .border(1.dp, Color(0xFF1C1C1C))
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    MetadataRow("PIXEL FORMAT", "yuv420p10le (10-bit Little Endian)")
                    MetadataRow("COLOR PRIMARIES", "BT.2020 Wide Color Gamut")
                    MetadataRow("TRANSFER FUNCTION", "SMPTE ST 2084 (Perceptual Quantizer)")
                    MetadataRow("COLOR MATRIX", "BT.2020 Non-Constant Luminance (nc)")
                    MetadataRow("TARGET BIT DEPTH", "10-bit Main10 Profile")
                    MetadataRow("PEAK TARGET LUMINANCE", "1,000 Nits (cd/m²)")
                    MetadataRow("AUDIO PASS-THROUGH", "-c:a copy (Bit-exact stream copy)")
                }
            }
        }
    }
}

@Composable
private fun ProfileRadioCard(
    profile: OutputProfile,
    selected: Boolean,
    isProcessing: Boolean,
    modifier: Modifier = Modifier,
    onSelected: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (selected) AmberPrimary.copy(alpha = 0.08f) else Color.Transparent)
            .border(
                1.dp,
                if (selected) AmberPrimary.copy(alpha = 0.6f) else Color(0xFF2C2C2C),
                RoundedCornerShape(4.dp)
            )
            .clickable(enabled = !isProcessing) { onSelected() }
            .padding(vertical = 8.dp, horizontal = 6.dp)
            .testTag("radio_option_${profile.name}")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            RadioButton(
                selected = selected,
                onClick = if (!isProcessing) onSelected else null,
                colors = RadioButtonDefaults.colors(
                    selectedColor = AmberPrimary,
                    unselectedColor = TextMuted
                ),
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Column {
                Text(
                    text = profile.title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = if (selected) AmberPrimary else TextPrimary
                )
                Text(
                    text = if (profile == OutputProfile.HDR10) "BT.2020 / ST2084" else "Dynamic Metadata",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextMuted
                )
            }
        }
    }
}

@Composable
private fun ProcessingStatusSection(
    isProcessing: Boolean,
    statusMessage: String,
    progress: Float,
    lastLog: String,
    logHistory: List<String>,
    outputFilePath: String?,
    onPlayClicked: () -> Unit,
    onShareClicked: () -> Unit
) {
    SectionContainer(title = "▪ PROCESSING STATUS", tag = "processing_status_section") {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Pulsing dot indicator
                StatusDot(isProcessing = isProcessing, isSuccess = outputFilePath != null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = statusMessage,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    letterSpacing = 0.8.sp,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (isProcessing) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .background(PureBlack, RoundedCornerShape(2.dp))
                            .border(1.dp, AmberPrimary, RoundedCornerShape(2.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Progress: ${(progress * 100).toInt()}%",
                            color = AmberPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Linear Progress Indicator when active
            if (isProcessing) {
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(5.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .testTag("conversion_progress_indicator"),
                    color = AmberPrimary,
                    trackColor = Color(0xFF222222)
                )
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Real-time terminal / log window
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF050505))
                    .border(1.dp, Color(0xFF1E1E1E))
                    .padding(8.dp)
                    .testTag("terminal_log_box")
            ) {
                if (logHistory.isEmpty()) {
                    Text(
                        text = if (lastLog.isEmpty()) "> SYSTEM ENGINE READY" else "> $lastLog",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = AmberPrimary,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                } else {
                    val listState = rememberLazyListState()
                    LaunchedEffect(logHistory.size) {
                        listState.animateScrollToItem(logHistory.size - 1)
                    }
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 100.dp)
                    ) {
                        items(logHistory) { line ->
                            Text(
                                text = line,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (line.startsWith("> ERROR")) StatusError else AmberPrimary,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }
            }

            // Success action bar if output video was generated
            if (outputFilePath != null && !isProcessing) {
                Spacer(modifier = Modifier.height(12.dp))
                OutputCompletedCard(
                    filePath = outputFilePath,
                    onPlayClicked = onPlayClicked,
                    onShareClicked = onShareClicked
                )
            }
        }
    }
}

@Composable
private fun StatusDot(isProcessing: Boolean, isSuccess: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dotAlpha"
    )

    val color = when {
        isProcessing -> AmberPrimary.copy(alpha = alpha)
        isSuccess -> StatusSuccess
        else -> StatusSuccess
    }

    Box(
        modifier = Modifier
            .size(9.dp)
            .background(color, CircleShape)
            .border(1.dp, color.copy(alpha = 0.5f), CircleShape)
    )
}

@Composable
private fun OutputCompletedCard(
    filePath: String,
    onPlayClicked: () -> Unit,
    onShareClicked: () -> Unit
) {
    ContainerBox(
        borderColor = StatusSuccess,
        borderWidth = 1.dp,
        modifier = Modifier.testTag("output_completed_card")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Success",
                    tint = StatusSuccess,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "MASTERING SELESAI!",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = StatusSuccess
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Tersimpan: ${filePath.substringAfterLast("/")}",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onPlayClicked,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AmberPrimary,
                        contentColor = PureBlack
                    ),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .testTag("play_video_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = PureBlack,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "PUTAR VIDEO",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }

                OutlinedButton(
                    onClick = onShareClicked,
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = TextPrimary
                    ),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = androidx.compose.ui.graphics.SolidColor(Color(0xFF333333))
                    ),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .testTag("share_video_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share",
                        tint = TextPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "BAGIKAN",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun HdrEngineBottomBar(
    isProcessing: Boolean,
    hasSource: Boolean,
    onConvertClicked: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(PureBlack)
            .border(
                width = 1.dp,
                color = Color(0xFF2C2C2C),
                shape = RoundedCornerShape(0.dp)
            )
            .padding(16.dp)
            .testTag("bottom_action_bar")
    ) {
        Button(
            onClick = onConvertClicked,
            enabled = !isProcessing,
            colors = ButtonDefaults.buttonColors(
                containerColor = AmberPrimary,
                contentColor = PureBlack,
                disabledContainerColor = Color(0xFF332900),
                disabledContentColor = Color(0x66FFC107)
            ),
            shape = RoundedCornerShape(4.dp),
            elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("convert_to_hdr_button")
        ) {
            if (isProcessing) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    CircularProgressIndicator(
                        strokeWidth = 2.dp,
                        color = Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "PROCESSING MASTER...",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        letterSpacing = 1.5.sp,
                        color = Color.White.copy(alpha = 0.8f)
                    )
                }
            } else {
                Text(
                    text = "CONVERT TO DOLBY VISION",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp,
                    letterSpacing = 1.5.sp,
                    color = PureBlack
                )
            }
        }
    }
}

@Composable
private fun SectionContainer(
    title: String,
    tag: String,
    child: @Composable () -> Unit
) {
    ContainerBox(
        borderColor = AmberPrimary.copy(alpha = 0.5f),
        borderWidth = 1.dp,
        modifier = Modifier.testTag(tag)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = title,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 12.sp,
                letterSpacing = 1.2.sp,
                color = AmberPrimary
            )
            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = AmberPrimary, thickness = 1.dp)
            Spacer(modifier = Modifier.height(12.dp))
            child()
        }
    }
}

@Composable
private fun ContainerBox(
    modifier: Modifier = Modifier,
    borderColor: Color = AmberPrimary.copy(alpha = 0.5f),
    borderWidth: androidx.compose.ui.unit.Dp = 1.dp,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF1E1E1E), RoundedCornerShape(4.dp))
            .border(borderWidth, borderColor, RoundedCornerShape(4.dp))
    ) {
        content()
    }
}
