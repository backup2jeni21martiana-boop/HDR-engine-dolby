package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val HdrEngineColorScheme = darkColorScheme(
    primary = AmberPrimary,
    onPrimary = PureBlack,
    primaryContainer = AmberDeep,
    onPrimaryContainer = AmberLight,
    secondary = AmberLight,
    onSecondary = PureBlack,
    tertiary = AmberDark,
    onTertiary = PureBlack,
    background = PureBlack,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkElevated,
    onSurfaceVariant = TextSecondary,
    outline = DarkBorder,
    outlineVariant = Color(0xFF1C1C1C),
)

@Composable
fun HdrEngineTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = HdrEngineColorScheme,
        typography = Typography,
        content = content
    )
}
