package com.example.model

import android.net.Uri

data class SourceVideoInfo(
    val uri: Uri,
    val fileName: String,
    val filePath: String,
    val fileSizeFormatted: String,
    val durationSeconds: Long = 0,
    val resolution: String = "1920x1080",
    val frameRate: String = "24.0 fps",
    val sourceCodec: String = "H.264 / AVC (8-bit)",
    val sourceColorSpace: String = "Rec.709 (SDR)"
)

enum class OutputProfile(
    val title: String,
    val subtitle: String,
    val x265Params: String,
    val description: String
) {
    HDR10(
        title = "HDR10",
        subtitle = "HEVC Main10 PQ ST2084 / BT.2020nc",
        x265Params = "colorprim=bt2020:transfer=smpte2084:colormatrix=bt2020nc",
        description = "Standard 10-bit SMPTE ST 2084 PQ transfer curve with BT.2020 Wide Color Gamut."
    ),
    HDR10_PLUS_MAX(
        title = "HDR10+ MAX",
        subtitle = "Enhanced Dynamic Metadata & AQ Mode 3",
        x265Params = "colorprim=bt2020:transfer=smpte2084:colormatrix=bt2020nc:hdr10-opt=1:repeat-headers=1:aq-mode=3",
        description = "Dynamic metadata mastering simulation with Adaptive Quantization Mode 3 and HDR10-optimized SEI NAL repetition."
    )
}

data class MasteringState(
    val sourceVideo: SourceVideoInfo? = null,
    val selectedProfile: OutputProfile = OutputProfile.HDR10,
    val selectedFps: String = "Original",
    val selectedNits: Int = 1000,
    val isProcessing: Boolean = false,
    val progress: Float = 0f,
    val statusMessage: String = "IDLE - STANDBY FOR COMMAND",
    val lastLog: String = "",
    val logHistory: List<String> = emptyList(),
    val outputFilePath: String? = null,
    val outputFileName: String? = null,
    val generatedCommand: String = "",
    val isAdvancedOpen: Boolean = false,
    val targetBitrate: String = "24 Mbps (Studio Master)",
    val maxNits: Int = 1000
)
