package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.OutputProfile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read app name string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("HDR Engine", appName)
  }

  @Test
  fun `verify hdr profiles contain bt2020 and smpte2084 parameters`() {
    val hdr10 = OutputProfile.HDR10
    assertTrue(hdr10.x265Params.contains("colorprim=bt2020"))
    assertTrue(hdr10.x265Params.contains("transfer=smpte2084"))
    assertTrue(hdr10.x265Params.contains("colormatrix=bt2020nc"))

    val hdr10Plus = OutputProfile.HDR10_PLUS_MAX
    assertTrue(hdr10Plus.x265Params.contains("hdr10-opt=1"))
    assertTrue(hdr10Plus.x265Params.contains("aq-mode=3"))
  }
}
